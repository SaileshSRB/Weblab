// Import required modules
const express = require('express');
const app = express();
const bodyParser = require('body-parser');

// Use body-parser middleware to parse incoming request bodies
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files from the public directory
app.use(express.static('public'));

app.set('view engine', 'ejs');



// Set up a route to handle form submissions
app.post('/submit-form', (req, res) => {
  // Retrieve form data from request body
  const { name, email, phone } = req.body;
  
  // Render a new page with the submitted form data
  res.render('form-details', { name, email, phone });
});

// Start the server
app.listen(3002, () => console.log('Server running on port 3002'));
