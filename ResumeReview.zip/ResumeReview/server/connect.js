const mongoose = require('mongoose')

const connectionString = 
'mongodb+srv://saravana03:1234@cluster0.tsvgx2o.mongodb.net/Apartments?retryWrites=true&w=majority'

const connectDB = (url) => {
    return mongoose
        .connect(connectionString, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            useFindAndModify: false,
            useCreateIndex: true
        })
}

module.exports = connectDB
